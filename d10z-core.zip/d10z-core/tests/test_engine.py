def test(): assert True
