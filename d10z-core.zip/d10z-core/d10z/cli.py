def init(): print('D10Z READY')
