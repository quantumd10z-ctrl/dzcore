def nodal_energy(x): return x
